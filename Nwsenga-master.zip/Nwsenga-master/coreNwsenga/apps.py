from django.apps import AppConfig


class CorenwsengaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'coreNwsenga'
